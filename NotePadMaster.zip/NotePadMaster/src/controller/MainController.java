package controller;

import form.MainForm;

/**
 *
 * @author Shams GamalS
 */
public class MainController {
    public static void main(String[] args) {
        MainForm mainForm = new MainForm();
        mainForm.setVisible(true);
        
        //Without Design Pattern
       /* EditController edit = new EditController();
        edit.controller(mainForm);
        
        FileController file = new FileController();
        file.controller(mainForm);*/
        /////////////////////////////////////////////////
        //With Design Pattern Factory//
        Controller_Factory cf = new Controller_Factory();
        
        //get an object of controller edit and call function controller
        Controller cedit = cf.getInstance("editcontroller");
        cedit.controller(mainForm);
        
        //get an object of controller file and call function controller
       Controller cfile = cf.getInstance("filecontroller");
       cfile.controller(mainForm);
        
    }
}
