 
package controller;

import form.MainForm;

/**
 *
 * @author Shams Gamal
 */
public interface Controller {
    
     void controller(MainForm mainForm);
    
}
